
import tensorflow as tf

x = tf.placeholder(tf.float32, [None])
y = tf.placeholder(tf.float32, [None])

two = tf.constant(2.0)

op1 = tf.multiply(x, x)
op2 = tf.multiply(op1, y)
op3 = tf.multiply(y, two)
op4 = tf.add(op2, op3)

sess = tf.Session()

result = sess.run(op4, feed_dict={x :[1 ,2 ,3], y :[2 ,7 ,1]})
results = sess.run([op2, op3, op4], feed_dict={x :[1 ,2 ,3], y :[2 ,7 ,1]})


tf.reset_default_gragh()
from random import shuffle, seed
import numpy as np
from util import load_iris

d_iris, l_iris = load_iris()
num = list(range(len(d_iris)))
seed(0)
shuffle(num)
d_iris = d_iris[num]
l_iris = l_iris[num]

d = d_iris[:, 0:3]
t = d_iris[:, -1]

X = tf.placeholder(tf.float32, [None,3])
y = tf.placeholder(tf.float32, [None])
W = tf.get_variable("W", [3, 1], initializer=tf.initializers.truncated_normal())
b = tf.get_variable("b", [1], initializer=tf.initializers.zeros())
pred = tf.add(tf.matmul(X, W), b)

loss = tf.reduce_mean(tf.pow(pred-y, 2))
optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.1)
train_op = optimizer.minimize(loss)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for step in range(100):
    _, loss_train = sess.run([train_op, loss], feed_dict={X:d, y:t})
    if np.isnan(loss_train) or np.isinf(loss_train):
        print("loss value overflowed")
        break
    print(step, loss_train, sess.run(W), sess.run(b))

results = sess.run(pred, feed_dict={X:d[:2], y:t[:2]})

tf.reset_default_graph()
X = tf.placeholder(tf.float32, [None, 4])
Y = tf.placeholder(tf.float32, [None, 3])

W = tf.get_variable("W", [4,3], initializer=tf.initializers.truncated_normal())
b = tf.get_variable("b", [3], initializer=tf.initializers.zeros())

pred = tf.nn.softmax(tf.add(tf.matmul(X,W), b))

# loss = -tf.reduce_sum(Y*tf.log(pred))
loss = -tf.reduce_mean(Y*tf.log(pred))

optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.1)
train_op = optimizer.minimize(loss)

correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(Y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

labels_onehot = np.zeros((len(l_iris), 3))
labels_onehot[np.arange(len(l_iris)), l_iris] = 1

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for step in range(1000):
    _, loss_train, acc_tr = sess.run([train_op, loss, accuracy],
                             feed_dict={X:d_iris, Y:labels_onehot})
    if np.isnan(loss_train) or np.isinf(loss_train):
        print("loss value overflowed")
        break
    print(step, loss_train, acc_tr)