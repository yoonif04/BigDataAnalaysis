
import pandas as pd
import numpy as np

telco = pd.read_csv('telco.csv')
telco.info()

# 평균 데이터로 채우기
np_mincallcost = telco['분당통화요금'].values
mask = np_mincallcost != '?'
sum(mask)
mask_na =[not x for x in mask]
f_mcc = np.array(np_mincallcost[mask], dtype=np.float32)
means = np.mean(np_mincallcost[mask].astype(np.float32))

np_mincallcost[mask_na] = str(means)
np_mincallcost = np_mincallcost.astype(np.float32)

# na_values 없앰
telco = pd.read_csv('telco.csv', na_values='?').dropna()
np_mincallcost = telco['분당통화요금'].values

# 이산형 변경
 # 이진 변수로 변경
uniq_gender =set(telco['성별'])
only_women = telco['성별'] == '여'
only_men = telco['성별'] == '남'

np_ow = only_women.astype(np.int32).values
np_om = only_men.astype(np.int32).values

np_gender = np.vstack((np_ow, np_om))
np_gender = np.transpose(np_gender)

 # handset
uniq_hand = list(set(telco['핸드셋']))
l_np_hand = []
for each_handset in uniq_hand:
    only_hand = telco['핸드셋'] == each_handset

    np_hand = only_hand.astype(np.int32).values
    l_np_hand.append(np_hand)

np_handset = np.vstack(l_np_hand)
np_handset = np.transpose(np_handset)

# Normalize Continuous Features
ptile = np.percentile(telco['국내통화요금_분'].values, [0, 25, 50, 75, 100])
hist = np.histogram(telco['국내통화요금_분'].values, bins=10)

import matplotlib.pyplot as plt
# histogram 1 : 0이 매우 많다
plt.hist(telco['국내통화요금_분'].values)

# histogram 2 : 0이 매우 많다
l_count = [0]
for i in range(1, 11, 1):
    pivot = i*(ptile[-1] - ptile[0])/10
    c = sum(telco['국내통화요금_분'].values <= pivot)
    l_count.append(c)

np_count = np.array(l_count)
diff = np_count[1:] - np_count[:-1]
print(diff, "length:", len(diff))
plt.plot(diff)

# log 씌워서 보정 (but, log0 음의 무한대 ->1을 더해줌)+ 0,1 normalization
np_incost = np.log(telco['국내통화요금_분'].values + 1)
np_incost = (np_incost-min(np_incost))/(max(np_incost)-min(np_incost))
plt.hist(np_incost)

# Merge the Features
total = np.column_stack([np_gender, np_handset, np_mincallcost, np_incost])

# target
y = (telco['이탈여부'].values == '유지').astype(np.int)
prior = sum(y)/len(y)         # 유지 비율

