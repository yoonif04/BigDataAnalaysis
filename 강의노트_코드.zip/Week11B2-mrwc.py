
from mrjob.job import MRJob
import re

class MRWoldFreqCount(MRJob):
    def mapper(self, _, line):
        tokens = line.split()
        for w in tokens:
            w = w.lower()
            w = re.sub("[^a-z]", "", w)
            yield (w, 1)

    def reducer(self, word, counts):
        yield ( word, sum(counts))

if __name__ == '__main__':
    MRWoldFreqCount.run()