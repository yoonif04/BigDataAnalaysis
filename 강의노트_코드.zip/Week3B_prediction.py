import numpy as np
import pandas as pd
import seaborn as sb
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt

advertise = pd.read_csv('Advertising.csv', usecols=[1, 2, 3, 4])
advertise.head()
advertise.tail()

advertise.shape
advertise.index
advertise.columns
advertise.info()

sb.pairplot(advertise)

lm = smf.ols(formula= 'sales ~ TV', data=advertise)
lm_hat = lm.fit()

lm_hat.summary()
print(lm_hat.summary().tables[2])

plt.scatter(advertise.TV, advertise.sales)
plt.xlabel("TV")
plt.ylabel("sales")

x = pd.DataFrame({'TV': [advertise.TV.min(),advertise.TV.max()] })
y_pred = lm_hat.predict(x)
plt.plot(x, y_pred, c="red")
plt.title("Simplt Linear Regression")

lm_mul = smf.ols(formula= 'sales ~ TV + radio + newspaper', data=advertise)
lml_hat = lm_mul.fit()
lml_hat.summary()

credit = pd.read_csv('Credit.csv', usecols=list(range(1,12)))
lm = smf.ols(formula='Balance ~ Gender', data=credit)
lm_hat = lm.fit()
lm_hat.summary()

credit.Ethnicity.unique()
lm = smf.ols(formula='Balance ~ Ethnicity', data=credit)
lm_hat = lm.fit()
lm_hat.summary()

lm_all = smf.ols("Balance ~ Income + Limit + Rating + Cards + Age + Education + Gender + Student + Married ", credit).fit()
lm_all.summary()

lm_interact = smf.ols('sales~ TV + radio + TV:radio', advertise).fit()
lm_interact.summary()

smf.ols('sales ~ TV + newspaper*radio', advertise).fit().summary()

lm_no_inter = smf.ols("Balance ~ Income+Student ",credit).fit()

auto = pd.read_csv('Auto.csv')
auto.info()

auto_problem = auto[auto.horsepower.apply(lambda x : not(x.isnumeric()))]

auto = pd.read_csv('Auto.csv', na_values='?').dropna()
# 0.688
lm_quad = smf.ols('mpg ~ horsepower + pow(horsepower, 2)', auto).fit()
lm_quad.summary()

# 0.606
lm_quad1 = smf.ols('mpg ~ horsepower ', auto).fit()
lm_quad1.summary()

# 0.688
lm_quad3 = smf.ols('mpg ~ horsepower + pow(horsepower, 2)+ pow(horsepower, 3)', auto).fit()
lm_quad3.summary()

X = pd.DataFrame({'horsepower': np.arange(auto.horsepower.min(), auto.horsepower.max(),0.5)})
Y_pred = lm_quad3.predict(X)
plt.scatter(auto.horsepower, auto.mpg)
plt.xlabel("horsepower")
plt.ylabel("mpg")
plt.plot(X,Y_pred, c='red')
plt.title("Multiple Linear Regression")