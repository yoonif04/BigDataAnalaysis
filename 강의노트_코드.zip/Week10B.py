
from util import load_iris
from random import shuffle, seed
import numpy as np

seed(0)
d_iris, l_iris = load_iris()

numbers = list(range(len(d_iris)))
shuffle(numbers)
d_iris = d_iris[numbers]
l_iris = l_iris[numbers]
d_iris_tr = d_iris[:130]
l_iris_tr = l_iris[:130]
d_iris_te = d_iris[130:]
l_iris_te = l_iris[130:]

from sklearn.cluster import KMeans
clu = KMeans(n_clusters=3)
clu.fit(d_iris_tr, l_iris_tr)
clusters = clu.predict(d_iris_tr)

print(clu.cluster_centers_)

# 시각화
from sklearn.decomposition import PCA as skPCA

skpc = skPCA(n_components=4)
skpc.fit(d_iris_tr)
transformed = skpc.transform(d_iris_tr)
skpc.explained_variance_ratio_

import matplotlib.pyplot as plt
import pandas as pd


axis = ['PC1', 'PC2']
df_ir_pca = pd.DataFrame(transformed[:, :2], columns=axis)
df_ir_pca['target'] = l_iris_tr

labels = ['setosa', 'versicolar', 'virginica']
markers = ['^', 's', 'o']

for i, marker in enumerate(markers):
    x_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC1']
    y_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC2']
    plt.scatter(x_axis_data, y_axis_data, marker=marker, label=labels[i])
plt.legend(loc='upper right')
plt.xlabel("pc1")
plt.ylabel('pc2')

t_centroid = skpc.transform(clu.cluster_centers_)
plt.scatter(t_centroid[:, 0], t_centroid[:, 1], c='red', marker='*')

from util import calc_intra_cluster_score, calc_inter_cluster_score

l_centroid = []
res = []
for i in range(2, 8):
    clu = KMeans(n_clusters=i, n_jobs=4)
    clu.fit(d_iris_tr, l_iris_tr)
    clusters = clu.predict(d_iris_tr)
    s_intra = calc_intra_cluster_score(d_iris_tr, clusters, clu.cluster_centers_)
    s_inter = calc_inter_cluster_score(clu.cluster_centers_)
    res.append((s_intra, s_inter))
    l_centroid.append(clu.cluster_centers_)

plt.plot(res)
plt.xticks(np.arange(6), [str(x) for x in range(2, 8)])
plt.xlabel("# of clusters")
plt.ylabel('scores')

# 군집 7개인 경우
from sklearn.decomposition import PCA as skPCA

skpc = skPCA(n_components=4)
skpc.fit(d_iris_tr)
transformed = skpc.transform(d_iris_tr)
skpc.explained_variance_ratio_

import matplotlib.pyplot as plt
import pandas as pd


axis = ['PC1', 'PC2']
df_ir_pca = pd.DataFrame(transformed[:, :2], columns=axis)
df_ir_pca['target'] = l_iris_tr

labels = ['setosa', 'versicolar', 'virginica']
markers = ['^', 's', 'o']

for i, marker in enumerate(markers):
    x_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC1']
    y_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC2']
    plt.scatter(x_axis_data, y_axis_data, marker=marker, label=labels[i])
plt.legend(loc='upper right')
plt.xlabel("pc1")
plt.ylabel('pc2')

t_centroid = skpc.transform(l_centroid[-1])
plt.scatter(t_centroid[:, 0], t_centroid[:, 1], c='red', marker='*')

idx = len(l_centroid[-1])
for j in range(len(t_centroid)):
    plt.annotate(idx, (t_centroid[j, 0], t_centroid[j, 1]))


# Agglomerative Clustering
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
clu = AgglomerativeClustering(distance_threshold=0, n_clusters=None)
clu.fit(d_iris_te)
plt.title('Dendrogram')

from scipy.cluster.hierarchy import dendrogram
from util import plot_dendrogram
plot_dendrogram(clu, truncate_mode='level', p=0)

print(clu.children_)
print(clu.distances_)

# 밀도 군집화
from sklearn.datasets import make_circles, make_moons

n_samples = 1000
np.random.seed(0)

x1, y1 = make_circles(n_samples=n_samples, factor=.5, noise=.09)
x2, y2 = make_moons(n_samples=n_samples, noise=.05)
x3, y3 = make_moons(n_samples=n_samples, noise=.1)

for c in range(len(set(y1))):
    plt.scatter(x1[y1 == c, 0], x1[y1 == c, 1], s=5)
for c in range(len(set(y2))):
    plt.scatter(x1[y2 == c, 0], x2[y2 == c, 1], s=5)

from sklearn.cluster import DBSCAN
clu = DBSCAN()
clusters = clu.fit_predict(x2)

clu = DBSCAN(eps=0.05)
clusters = clu.fit_predict(x2)
idx_outlier = clusters == -1
plt.scatter(x2[idx_outlier, 0], x2[idx_outlier, 1], marker='x', lw=1, s=20)
for i in range(len(set(clusters))-1):
    plt.scatter(x2[clusters == i, 0], x2[clusters == i, 1], marker='o', s=20)

# Spectral Clustering
from sklearn.cluster import SpectralClustering
clu = SpectralClustering(n_clusters=2, eigen_solver="arpack", affinity="nearest_neighbors")
clu.fit(x2)
y_pred = clu.labels_
plt.scatter(x2[y_pred == 0, 0], x2[y_pred == 0, 1], marker='o', s=5)
plt.scatter(x2[y_pred == 1, 0], x2[y_pred == 1, 1], marker='o', s=5)

clu = SpectralClustering(n_clusters=2, eigen_solver="arpack", affinity="nearest_neighbors")
clu.fit(x3)
y_pred = clu.labels_
plt.scatter(x3[y_pred == 0, 0], x3[y_pred == 0, 1], marker='o', s=5)
plt.scatter(x3[y_pred == 1, 0], x3[y_pred == 1, 1], marker='o', s=5)


# Gaussian Mixture Model
from sklearn.mixture import GaussianMixture
means = np.array([d_iris_tr[l_iris_tr == i].mean(axis=0) for i in range(3)])
clu = GaussianMixture(n_components=3, means_init=means)
clu.fit(d_iris_tr)
y_pred = clu.predict(d_iris_tr)
correct = y_pred == l_iris_tr
acc = sum(correct)/len(correct)

# 신뢰구간을 타원으로 표현해보기
import matplotlib.pyplot as plt
import matplotlib as mpl

colors = ['navy', 'turquoise', 'darkorange']
ax = plt.subplot()

for n, color in enumerate(colors):
    plt.scatter(d_iris_tr[l_iris_tr == n, 0], d_iris_tr[l_iris_tr == n, 1], marker='s', s=5, color=color)

    covariance = clu.covariances_[n][:2, :2]
    v, w = np.linalg.eigh(covariance)
    u = w[0] / np.linalg.norm(w[0])
    angle = np.arctan2(u[1], u[0])
    angle = 180 * angle / np.pi
    v = 2.0 * np.sqrt(4.605) * np.sqrt(v)
    ell = mpl.patches.Ellipse(clu.means_[n, :2], v[0], v[1], angle, color=color)
    ell.set_alpha(0.5)

    ax.add_artist(ell)
    ax.set_aspect('equal', 'datalim')

