import numpy as np

ar = np.array([1, 2, 3, 4])
ar = np.array(range(9))

ar.shape

v = np.array(range(9))
m = v.reshape((3, 3))
m * 3 + 10
addm = np.array([10 for _ in range(9)])
addm = addm.reshape((3, 3))
3 * m + addm

a = np.array([1, 2, 3])
a.dtype
b = np.array([0.2, 0.3, 0.4])
b.dtype

c = np.array([1, 2, 3], dtype = np.float32)
c.dtype

np.eye(3)
np.diag([1, 2, 3])

ar = np.array(range(16)).reshape(4, 4)
ar[-1, -1]

ar[:, ::2]

ar = np.array(range(5))
b = ar[1:3]
b[:] = 0
b
ar

a = np.array(range(4))
b = np.array(sorted(range(4), reverse = True))
a>b
a = np.array(range(10)).reshape((2,5))
a.sum()
a.sum(axis = 0)

b = np.array([1, 2, 3, 4])
b = b[np.newaxis,:]
b.shape

a = np.array([1, 2, 3, 4]).reshape((4,1))
b = np.array([5, 6, 7, 8]).reshape((4,1))
np.matmul(a.transpose(),b)

np.hstack((a,b))
np.vstack((a,b))