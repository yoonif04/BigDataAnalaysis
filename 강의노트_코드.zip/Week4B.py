import numpy as np
import pandas as pd
from sklearn.datasets import load_iris

iris = load_iris()
iris.feature_names
iris.data[:4]

iris.target_names
iris.target[:4]


def fivesum(data):
    return np.percentile(data, [0, 25, 50, 75, 100])


iris_label = iris.target.reshape((150, 1))
iris_concat = np.hstack((iris.data, iris_label))
iris_pd = pd.DataFrame(iris_concat, columns=[*iris.feature_names, "Species"])

import seaborn as sns

sns.pairplot(iris_pd, vars=iris.feature_names, hue="Species", markers=['o', 's', 'p'])

from sklearn.tree import DecisionTreeClassifier

data = iris.data
labels = iris.target

clf = DecisionTreeClassifier()
clff = clf.fit(data, labels)
pred = clff.predict(data)
correct = pred == labels
acc = sum(correct) / len(correct)

from random import shuffle, seed

seed(0)
numbers = list(range(len(data)))
shuffle(numbers)
numbers[:5]

split_point = int(len(data) * 0.7)
data_tr = data[numbers[:split_point]]
labels_tr = labels[numbers[:split_point]]

data_te = data[numbers[split_point:]]
labels_te = labels[numbers[split_point:]]

clf = clf.fit(data_tr, labels_tr)
pred = clf.predict(data)
correct = pred == labels
acc = sum(correct) / len(correct)

from sklearn.tree import export_graphviz

export_graphviz(clf, out_file="dt.gv")

import pydotplus

graph = pydotplus.graph_from_dot_file("dt.gv")
graph.write_png("dt.png")
