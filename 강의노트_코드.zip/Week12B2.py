from random import seed, shuffle

import tensorflow as tf
import numpy as np

from util import load_iris

d_iris, l_iris = load_iris()
num = list(range(len(d_iris)))
seed(0)
shuffle(num)
d_iris = d_iris[num]
l_iris = l_iris[num]

tf.reset_default_graph()

X = tf.placeholder(tf.float32, [None, 4])
Y = tf.placeholder(tf.float32, [None, 3])

hidden_dim = 10
U = tf.get_variable("U", [4, hidden_dim], initializer=tf.initializers.truncated_normal())

bu = tf.get_variable("bu", [hidden_dim], initializer=tf.initializers.zeros())

V = tf.get_variable("V", [hidden_dim, 3], initializer=tf.initializers.truncated_normal())

bv = tf.get_variable("bv", [3], initializer=tf.initializers.zeros())

hidden_layer = tf.nn.sigmoid(tf.add(tf.matmul(X, U), bu))
out = tf.add(tf.matmul(hidden_layer, V), bv)
pred = tf.nn.softmax(out)


innerterm = tf.reduce_sum(Y*tf.log(pred), axis=1)
ce = -tf.reduce_sum(innerterm)

# ce = tf.losses.softmax_cross_entropy(Y, out)

optimizer = tf.train.GradientDescentOptimizer(learning_rate=0.1)
train_op = optimizer.minimize(ce)

correct_prediction = tf.equal(tf.argmax(pred, 1), tf.argmax(Y ,1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

labels_onehot = np.zeros((len(l_iris), 3))
labels_onehot[np.arange(len(l_iris)), l_iris] = 1

sess = tf.Session()
sess.run(tf.global_variables_initializer())

for step in range(1000):
    _, loss_train, acc_tr = sess.run([train_op, ce, accuracy],
                             feed_dict={X:d_iris, Y:labels_onehot})
    if np.isnan(loss_train) or np.isinf(loss_train):
        print("loss value overflowed")
        break
    print(step, loss_train, acc_tr)