
from mrjob.job import MRJob

class MRTelco(MRJob):
    def mapper(self, _, line):
        if "이탈여부" not in line:
            tokens = line.split(',')[9:11]
            yield (tokens[1], 0 if '이탈' in tokens[0] else 1)


    def reducer(self, handset, yesno):
        l_v = list(yesno)
        yield ( handset, sum(l_v)/len(l_v))

if __name__ == '__main__':
    MRTelco.run()