from util import load_iris
from random import shuffle, seed
import numpy as np
seed(0)

d_iris, l_iris = load_iris()

numbers = list(range(len(d_iris)))
shuffle(numbers)
d_iris = d_iris[numbers]
l_iris = l_iris[numbers]

d_iris_tr = d_iris[:110]
d_iris_v = d_iris[110:130]
d_iris_te = d_iris[130:]
l_iris_tr = l_iris[:110]
l_iris_v = l_iris[110:130]
l_iris_te = l_iris[130:]

from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import f1_score
l_clf = []
l_clf.append(LinearDiscriminantAnalysis())
l_clf.append(LogisticRegression())
l_clf.append(MLPClassifier())

voted = []
l_f1_score = []
for each_clf in l_clf:
    each_clf.fit(d_iris_tr, l_iris_tr)
    pred = each_clf.predict(d_iris_te)
    s = f1_score(l_iris_te, pred, average='macro')
    l_f1_score.append(s)
    voted.append(pred)


from collections import Counter
voted = np.array(voted)
voted = np.transpose(voted)
final_pred = []
for each in voted:
    ed = Counter(each)
    majority = sorted(ed.items(), key=lambda x: x[1], reverse=True)[0]
    final_pred.append(majority[0])
final_s = f1_score(l_iris_te, final_pred, average='macro')


import pandas as pd
from random import shuffle, seed
advertising = pd.read_csv('Advertising.csv', usecols=[1, 2, 3, 4])
d_ad = advertising.values[:, :3]
t_ad = advertising.values[:, -1]

seed(0)
numbers = list(range(len(d_ad)))
shuffle(numbers)
d_ad = d_ad[numbers]
t_ad = t_ad[numbers]

d_ad_tr = d_ad[:170]
d_ad_v = d_ad[170:185]
d_ad_te = d_ad[185:]
t_ad_tr = t_ad[:170]
t_ad_v = t_ad[170:185]
t_ad_te = t_ad[185:]

from sklearn.svm import LinearSVR
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPRegressor

def calc_rmse(pred, true):
    rss = np.sum(np.power(pred - true, 2))
    mse = rss/len(pred)
    rmse = np.sqrt(mse)
    return rmse

l_clf = []
l_clf.append(LinearSVR())
l_clf.append(LinearRegression())
l_clf.append(MLPRegressor())

l_te_rmse = []
l_v_rmse = []
l_pred = []
for each_clf in l_clf:
    each_clf.fit(d_ad_tr, t_ad_tr)
    pred_te = each_clf.predict(d_ad_te)
    pred_v = each_clf.predict(d_ad_v)
    l_pred.append(pred_te)
    rmse_te = calc_rmse(pred_te, t_ad_te)
    rmse_v = calc_rmse(pred_v, t_ad_v)
    l_te_rmse.append(rmse_te)
    l_v_rmse.append(rmse_v)

l_pred = np.array(l_pred)
l_pred = np.transpose(l_pred)

w_per_m = 1/np.array(l_v_rmse)
w_per_m = w_per_m/sum(w_per_m)

weighter_pred = w_per_m * l_pred
weighter_pred = np.sum(weighter_pred, axis=1)

ensemble_rmse = calc_rmse(weighter_pred, t_ad_te)

# OVO
clf_only = LogisticRegression()
clf_only.fit(d_iris_tr,l_iris_tr)
pred = clf_only.predict(d_iris_te)
baseline = f1_score(l_iris_te, pred, average='macro')

def part_dataset(data,label):
    l_partition = []
    uniq = list(set(label))
    for each_class in uniq:
        mask = label == each_class
        selected = data[mask]
        l_partition.append([selected, np.zeros(len(selected))+each_class])
    return l_partition

l_part = part_dataset(d_iris_tr, l_iris_tr)

d_iris_tr01 = np.row_stack((l_part[0][0], l_part[1][0]))
d_iris_tr12 = np.row_stack((l_part[1][0], l_part[2][0]))
d_iris_tr02 = np.row_stack((l_part[0][0], l_part[2][0]))

l_iris_tr01 = np.concatenate((l_part[0][1], l_part[1][1]))
l_iris_tr12 = np.concatenate((l_part[1][1], l_part[2][1]))
l_iris_tr02 = np.concatenate((l_part[0][1], l_part[2][1]))

l_d_iris_tr = [d_iris_tr01, d_iris_tr12, d_iris_tr02]
l_l_iris_tr = [l_iris_tr01, l_iris_tr12, l_iris_tr02]

l_clf = [LogisticRegression() for _ in range(3)]

for clf, dtr, ltr in zip(l_clf,l_d_iris_tr,l_l_iris_tr):
    clf.fit(dtr, ltr)

total_prob = np.zeros((len(d_iris_te),3))
for clf, idx in zip(l_clf, [[0,1], [1,2], [0,2]]):
    pred = clf.predict_proba(d_iris_te)
    total_prob[:,idx] += pred

final_pred = np.argmax(total_prob, axis=1)
final_fscore = f1_score(l_iris_te, final_pred, average='macro')