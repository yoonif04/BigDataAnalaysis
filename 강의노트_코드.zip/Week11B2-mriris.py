
# from sklearn.datasets import load_iris
# iris = load_iris()
# data = iris.data
# label = iris.target
#
# f = open("iris.csv", 'w')
# for d, l in zip(data, label):
#     f.write("%f,%f,%f,%f,%d\n" %(*d, l))
# f.flush()
# f.close()

from mrjob.job import MRJob

n_feature = ['SL', 'SW', 'PL', 'PW']
n_labels = ['setosa', 'versicolor', 'virginica']

class MRAvgIris(MRJob):
    def mapper(self, _, line):
        tokens = [x.strip() for x in line.split(',')]

        features = tokens[:-1]
        label = int(tokens[-1])

        for n, f in zip(n_feature, tokens):
            yield ("%s_%s" % (n_labels[label], n), float(f))

    def reducer(self, attr, values):
        l_v = list(values)
        yield ( attr, sum(l_v)/len(l_v))

if __name__ == '__main__':
    MRAvgIris.run()