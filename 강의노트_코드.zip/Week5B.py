import numpy as np

f = open('train_mnist.csv', 'r')

f.readline()

l_digit = []
l_label = []
for line in f.readlines():
    splitted = line.replace("\n", "").split(",")
    label = int(splitted[0])
    digit = np.array(splitted[1:], dtype=np.float32)
    l_label.append(label)
    l_digit.append(digit)

digits = np.array(l_digit)
labels = np.array(l_label)

print(digits.shape)
f.close()

import matplotlib.pyplot as plt

dig = digits[55].reshape((28, 28))
fig, ax = plt.subplots()
cax = ax.imshow(dig, cmap='gray')
ax.set_title("digit %d"%labels[55])
cbar = fig.colorbar(cax, ticks = [0, 255/2, 255])

norm_digits = digits/255

from sklearn.linear_model import LogisticRegression as lr
from sklearn.datasets import load_iris

iris = load_iris()
iris_data = iris.data
iris_labels = iris.target
clf = lr()
clf = clf.fit(iris.data, iris.target)

#iris data
pred = clf.predict(iris.data)
correct = pred == iris.target
acc = sum(correct)/len(correct)

#MNIST
norm_digits = digits/255
clf = clf.fit(norm_digits[:200], labels[:200])
pred = clf.predict(norm_digits[200:400])
correct = pred == labels[200:400]
acc = sum(correct)/len(correct)

from sklearn.linear_model import Perceptron
clf = Perceptron(max_iter=500, n_jobs=3, eta0=0.1)
clf = clf.fit(norm_digits[:200], labels[:200])
pred = clf.predict(norm_digits[200:400])
correct = pred == labels[200:400]
acc = sum(correct)/len(correct)

from sklearn.neural_network import MLPClassifier as mlp
clf = mlp(hidden_layer_sizes=100, max_iter=500, learning_rate_init=0.1)
clf = clf.fit(norm_digits[:200], labels[:200])
pred = clf.predict(norm_digits[200:400])
correct = pred == labels[200:400]
acc = sum(correct)/len(correct)