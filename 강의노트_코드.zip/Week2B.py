def def__init__(self, id, name):
    pass


class Student:
    """이건 학생 클래스입니다."""

    id = 0
    name = ""

    def __init__(self, id, name):
        self.id = id
        self.name = name

    def printInfo(self):
        print(self.id, self.name)


from EXweek2A import students

s = Student(222, "Soongsil Kim")
s.__doc__
s.printInfo()

list(map(lambda x: x ** 2, range(5)))

list(map(lambda x : (x[0], sum(x[1])/ len(x[1])), list(students.items())))

from functools import reduce
reduce(lambda x,y: x*y, range(1,5))

path = "alice.txt"
f = open(path, 'r')

lines = f.readlines()
print(lines[0])
f.close()


f = open(path, 'r')
for line in f:
    print("--")
    print(line)
f.close()

f = open("result.txt", 'w')
f.write("문자열을 저장할거다. \n")
for i in range(10):
    f.write("%d\n" %i)
f.flush()
f.close()

from codecs import open as copen
f = copen("result2.txt", "w", "UTF-8")
f.write("문자열을 저장한다.\n")
for i in range(10):
    f.write(str(i)+"\n")
f.flush()
f.close()