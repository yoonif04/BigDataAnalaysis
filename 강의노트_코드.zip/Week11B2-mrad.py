

from mrjob.job import MRJob
import re

keys = ['TV', 'radio', 'newspaper', 'sales']
class MRAvgAdvertising(MRJob):
    def mapper(self, _, line):
        if "TV" not in line:
            tokens = [x.strip() for x in line.split(',')[1:]]

            for k, v in zip(keys, tokens):
                v = float(v)
                yield (k, v)

    def reducer(self, attr, values):
        l_v = list(values)
        yield ( attr, sum(l_v)/len(l_v))

if __name__ == '__main__':
    MRAvgAdvertising.run()