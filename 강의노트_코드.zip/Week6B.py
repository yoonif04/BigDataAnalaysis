from sklearn.discriminant_analysis import  LinearDiscriminantAnalysis as LDA

import numpy as np
import pandas as pd
import time
from random import shuffle, seed
import matplotlib.pyplot as plt
from util import load_iris, load_mnist, runCV

d_ir, l_ir = load_iris()
numbers = list(range(len(l_ir)))
seed(0)
shuffle(numbers)
sd_ir = d_ir[numbers]
sl_ir = l_ir[numbers]

clf =LDA(n_components=2)

results = runCV(clf, sd_ir, sl_ir)
mean_acc = np.mean(results)

d_digit, l_digit = load_mnist('train_mnist.csv')
numbers = list(range(len(l_ir)))
seed(0)
shuffle(numbers)
sd_digit = d_digit[numbers]
sl_digit = l_digit[numbers]
results = runCV(clf, d_digit, l_digit)
mean_acc = np.mean(results)

clf.fit(d_ir, l_ir)
d_ir_lda = clf.transform(d_ir)
d_ir_lda.shape

axis = ['LD1', 'LD2']
df_ir_lda = pd.DataFrame(d_ir_lda, columns=axis)
df_ir_lda['target'] = l_ir

labels = ['setosa', 'versicolor', 'verginica']
markers = ['^', 's', 'o']

for i, marker in enumerate(markers):
    x_axis_data = df_ir_lda[df_ir_lda['target'] == i]['LD1']
    y_axis_data = df_ir_lda[df_ir_lda['target'] == i]['LD2']
    plt.scatter(x_axis_data, y_axis_data, marker=marker, label=labels[i])
plt.legend(loc= 'upper right')
plt.xlabel('LD1')
plt.ylabel('LD2')
plt.show()

from sklearn.svm import LinearSVC
clf = LinearSVC()
numbers = list(range(len(d_ir)))
seed(0)
shuffle(numbers)
s_data = d_ir[numbers]
s_labels = l_ir[numbers]
results = runCV(clf, s_data, s_labels)
np.mean(results)

params = []
for k in ['linear', 'rbf', 'poly', 'sigmoid']:
    for C in [pow(10, x-3) for x in range(6)]:
        if k == 'linear':
            p = dict()
            p['kernel'] = k
            p['C'] = C
            params.append(p)
        elif k =='rbf':
            for gc in [pow(10, x-3) for x in range(6)]:
                p = dict()
                p['kernel'] = k
                p['C'] = C
                p['gamma'] = gc
                params.append(p)
        else:
            for gc in [pow(10, x - 3) for x in range(6)]:
                for coef in [pow(10, x - 3) for x in range(6)]:
                    p = dict()
                    p['kernel'] = k
                    p['C'] = C
                    p['gamma'] = gc
                    p['coef0'] = coef
                    params.append(p)

from sklearn.svm import SVC
means = dict()
for p in params:
    print(p)
    clf = SVC(**p)
    results = runCV(clf, s_data, s_labels)
    means[str(p)] = np.mean(results)
ordered = sorted(means.items(), key=lambda x:x[1], reverse=True)
best_param = ordered[0]


from sklearn.model_selection import GridSearchCV
param1 = {'kernel':['linear'], 'C': np.array([pow(10, x - 3) for x in range(6)])}
param2 = {'kernel':['poly', 'sigmoid'], 'C': np.array([pow(10, x - 3) for x in range(6)]), 'gamma': np.array([pow(10, x - 3) for x in range(6)]), 'coef0': np.array([pow(10, x - 3) for x in range(6)])}

svc = SVC()
clf = GridSearchCV(svc, param1, cv=5, n_jobs=1)
clf.fit(s_data, s_labels)

prms = clf.cv_results_['params']
acc_means = clf.cv_results_['mean_test_score']
for mean, prm in zip(acc_means, prms):
    print("%0.3f for %r" % (mean, prm))

st = time.time()
svc = SVC()
clf = GridSearchCV(svc, param2, cv=5, n_jobs=4)
clf.fit(s_data, s_labels)
et = time.time()
print(et-st)

from sklearn.metrics import f1_score,precision_score, recall_score, make_scorer
f1 = make_scorer(f1_score, average='macro')
pr = make_scorer(precision_score, average='macro')
re = make_scorer(recall_score, average='macro')

clf = GridSearchCV(svc, param2, cv=5, n_jobs=4,
                   scoring={'f1':f1, 'pr':pr,
                            're':re}, refit=False)
st = time.time()
clf.fit(s_data, s_labels)
et= time.time()
print(et-st)