def mp_print(prm):
    import numpy as np

    ID, count = prm

    for _ in range(count):
        print("MY ID is %d" %ID)

    return ID, np.random.randint(0, 100)



def run_and_test(params):
    import statsmodels.formula.api as smf
    import numpy as np

    candidate, lamb, credit_train, credit_test, cnames = params
    print("running now", lamb)
    order = "Balance ~%s" % ' + '.join([cnames[each_idx] for each_idx in candidate])
    lm_candi = smf.ols(order, credit_train).fit_regularized(alpha=lamb, L1_wt=0 )
    pred = lm_candi.predict(credit_test)
    diff = np.power(pred.values - credit_test.values[:, -1], 2)
    mse = np.sum(diff) / len(diff)
    rmse = np.sqrt(mse)

    return lamb, rmse


if __name__ == '__main__':
    from multiprocessing import Pool
    import numpy as np
    import pandas as pd
    from random import seed
    seed(0)

    credit = pd.read_csv('C:/Users/3covl/PycharmProjects/BigData/Credit.csv', usecols=list(range(1, 12)))
    credit = credit.sample(frac=1).reset_index(drop=True)
    credit_train = credit[:300]
    credit_test = credit[300:]
    cnames = credit.columns.values
    cnames = cnames[:-1]

    candi = list(range(len(cnames)))

    lamb = np.arange(0, 50, 0.5).tolist()
    ex_credit_train = [credit_train for _ in range(len(lamb))]
    ex_credit_test = [credit_test for _ in range(len(lamb))]
    ex_cnames = [cnames for _ in range(len(lamb))]
    ex_candi = [candi for _ in range(len(lamb))]
    params = list(zip(ex_candi, lamb, ex_credit_train, ex_credit_test, ex_cnames))

    pool = Pool(processes=3)
    results = pool.map(run_and_test, params)
    pool.close()
    pool.join()

    for la, rmse in results:
        print(la, rmse)

    import pickle

    with open('C:/Users/3covl/PycharmProjects/BigData/result.pkl', 'wb') as f:
        pickle.dump(results, f)
