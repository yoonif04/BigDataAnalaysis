from itertools import combinations

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

credit = pd.read_csv('Credit.csv', usecols=list(range(1, 12)))
credit.info()

credit = credit.sample(frac=1).reset_index(drop=True)
credit_train = credit[:300]
credit_test = credit[300:]

cnames = credit.columns.values
cnames = cnames[:-1]


def train_test_once(_candi):
    order = "Balance ~%s" % ' + '.join([cnames[each_idx] for each_idx in _candi])
    lm_candi = smf.ols(order, credit_train).fit()
    pred = lm_candi.predict(credit_test)
    diff = np.power(pred.values - credit_test.values[:, -1], 2)
    mse = np.sum(diff) / len(diff)
    return mse


# Best subset selection
res_best = []
for max_num in range(1, len(cnames)):
    idx_combi = list(combinations(list(range(len(cnames))), max_num))

    res_temp = []
    for candidate in idx_combi:
        mse = train_test_once(candidate)
        res_temp.append((candidate, mse))

    temp_best = sorted(res_temp, key=lambda x: x[1])[0]
    res_best.append(temp_best)

ascending = sorted(res_best, key=lambda x: x[1])
b_best_idx = ascending[0][0]
b_best_mse = ascending[0][1]
b_best_features = cnames[list(b_best_idx)]

# Forward selection
res_forward = []
for max_num in range(1, len(cnames)):
    if len(res_forward) != 0:
        before_best = res_forward[-1][0]
    else:
        before_best = []

    idx_combi = [[*before_best, idx] for idx in range(len(cnames)) if idx not in before_best]

    res_temp = []
    for candidate in idx_combi:
        mse = train_test_once(candidate)
        res_temp.append((candidate, mse))

    temp_best = sorted(res_temp, key=lambda x: x[1])[0]
    res_forward.append(temp_best)

ascending = sorted(res_forward, key=lambda x: x[1])
f_best_idx = ascending[0][0]
f_best_mse = ascending[0][1]
f_best_features = cnames[list(f_best_idx)]

# Backward selection
res_backward = []
before_best = list(range(len(cnames)))
for max_num in range(1, len(cnames)):
    idx_combi = [list(before_best) for _ in range(len(before_best))]
    list(map(lambda x: idx_combi[x[0]].remove(x[1]), enumerate(before_best)))

    res_temp = []
    for candidate in idx_combi:
        mse = train_test_once(candidate)
        res_temp.append((candidate, mse))

    temp_best = sorted(res_temp, key=lambda x: x[1])[0]
    res_backward.append(temp_best)

ascending = sorted(res_backward, key=lambda x: x[1])
ba_best_idx = ascending[0][0]
ba_best_mse = ascending[0][1]
ba_best_features = cnames[list(ba_best_idx)]

# Ridge or Lasso
_candi = before_best
candidate = list(range(len(cnames)))
order = "Balance ~%s" % ' + '.join([cnames[each_idx] for each_idx in candidate])
lm_en = smf.ols(order, credit_train).fit()
lm_en.params

lm_enR = smf.ols(order, credit_train).fit_regularized(alpha=1, L1_wt=0)
lm_enL = smf.ols(order, credit_train).fit_regularized(alpha=1, L1_wt=1)

res = []

for i in range(13):
    lamb = np.power(2, i)
    _lm_L = smf.ols(order, credit).fit_regularized(alpha=lamb, L1_wt=1)
    res.append(_lm_L)

param_only = list(map(lambda x: x.params.values, res))
param_only = np.array(param_only)

import matplotlib.pyplot as plt

plt.plot(param_only)
plt.xticks(np.arange(13), ["%d" % np.power(2, i) for i in range(13)])

# PCA with statsmodel
from util import load_iris

iris_data, iris_target = load_iris()
pd_iris = pd.DataFrame(iris_data, columns=['sl', 'sw', 'pl', 'pw'])

from statsmodels.multivariate.pca import PCA as smPCA

smpc = smPCA(pd_iris, standardize=False, demean=False, normalize=False)

tr1 = smpc.transformed_data
tr2 = np.matmul(pd_iris.values, smpc.loadings.values)

# PCA with sklearn
from sklearn.decomposition import PCA as skPCA

skpc = skPCA(n_components=4)
skpc.fit(iris_data)
tr3 = skpc.transform(iris_data)
skpc.explained_variance_ratio_

# Map to New Space using PC
import matplotlib.pyplot as plt

plt.tick_params(reset=True)
axis = ['PC1', 'PC2']
df_ir_pca = pd.DataFrame(tr3[:, :2], columns=axis)
df_ir_pca['target'] = iris_target
labels = ['setosa', 'versicolar', 'virginica']
markers = ['^', 's', 'o']

for i, marker in enumerate(markers):
    x_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC1']
    y_axis_data = df_ir_pca[df_ir_pca['target'] == i]['PC2']
    plt.scatter(x_axis_data, y_axis_data, marker=marker, label=labels[i])
plt.legend(loc='upper center')
plt.xlabel("pc1")
plt.ylabel('pc2')

# BiPlot
pcs = skpc.components_
for i in range(4):
    plt.arrow(0, 0, 3 * pcs[0, i], 3 * pcs[1, i], color='r', alpha=0.5)
    plt.text(3*pcs[0, i]*1.15, 3*pcs[1, i]*1.15, pd_iris.columns[i],
             color='b', ha='center', va='center')
